import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class LittleThread extends Thread
{
    protected String hf;
    String[] slovo = {" " , " " ," " , " " , " "};
    String[] alfavit = {"a" , "b" , "c" , "d" , "e" , "f" , "g" , "h" , "i" , "j" , "k" , "l" , "m" , "n" , "o" , "p" , "q", "r" , "s" , "t", "u" , "v" , "w" , "x","y","z"};
    String need;
    protected int num;
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        MessageDigest smth = MessageDigest.getInstance("SHA-256");
        return smth.digest(input.getBytes(StandardCharsets.UTF_8));
    }
    public static String toHexString(byte[] hf)
    {
        BigInteger numb = new BigInteger(1, hf);
        StringBuilder HexString = new StringBuilder(numb.toString(16));
        while (HexString.length() < 32)
        {
            HexString.insert(0, '0');
        }
        return HexString.toString();
    }
    public LittleThread(String hf , int num)
    {
        this.hf = hf;
        this.num = num;
    }
    public void run() {
        int l = alfavit.length;
        for(int i = 0 ; i < l ; i++)
        {
            slovo[0] = alfavit[i];
            for(int k = 0 ; k < l ; k++) {
                slovo[1] = alfavit[k];
                for (int s = 0; s < l; s++) {
                    slovo[2] = alfavit[s];
                    for (int m = 0; m < l; m++) {
                        slovo[3] = alfavit[m];
                        for (int n = 0; n < l; n++) {
                            slovo[4] = alfavit[n];
                            need = slovo[0] + slovo[1] + slovo[2] + slovo[3] + slovo[4];
                            String copy = need;
                            try {
                                need = toHexString(getSHA(need));
                            } catch (NoSuchAlgorithmException e) {
                                e.printStackTrace();
                            }
                            if (need.equals(hf)) {
                                System.out.println(hf + " " + copy);
                                Thread.interrupted();
                            }
                        }
                    }
                }
            }
        }
    }
}

public class MainThread {
    public static void main(String[] args){
        String hf1 = "1115dd800feaacefdf481f1f9070374a2a81e27880f187396db67958b207cbad";
        String hf2 = "3a7bd3e2360a3d29eea436fcfb7e44c735d117c42d1c1835420b6b9942dd4f1b";
        String hf3 = "74e1bb62f8dabb8125a58852b63bdf6eaef667cb56ac7f7cdba6d7305c50a22f";
        LittleThread FirstThread = new LittleThread(hf1 , 1);
        LittleThread SecondThread = new LittleThread(hf2 , 2);
        LittleThread ThirdThread = new LittleThread(hf3 , 3);
        FirstThread.start(); SecondThread.start(); ThirdThread.start();
    }
}
